package com.rbu.ecom.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ManagerDto {

	@NotNull
	@Size(max = 255)
	private String name;

	@NotNull
	@Size(max = 255)
	private String email;

	@NotNull
	@Size(max = 255)
	private String address;

	@NotNull
	@Size(max = 255)
	private String pin;

	@NotNull
	@Size(max = 255)
	private String phone;

	@NotNull
	@Size(max = 255)
	private String division;

	@NotNull
	private Integer salary;
	@NotNull
	@Size(max = 255)
	private String contrycode;

}
