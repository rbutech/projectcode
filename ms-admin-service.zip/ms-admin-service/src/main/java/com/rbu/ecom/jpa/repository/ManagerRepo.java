package com.rbu.ecom.jpa.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.rbu.ecom.jpa.model.Manager;

public interface ManagerRepo extends JpaRepository<Manager, Long>{

}
