package com.rbu.ecom.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.rbu.ecom.dto.ManagerDto;
import com.rbu.ecom.jpa.model.Manager;
import com.rbu.ecom.jpa.repository.ManagerRepo;

@Service
public class ManagerService {

	@Autowired
	ManagerRepo managerRepo;

	public Long createManager(ManagerDto managerdto) {
		Manager manager=new Manager();
		mapDtotoEntity(managerdto, manager);
		Long id=managerRepo.save(manager).getId();
		return id;
	}
	public void mapDtotoEntity(ManagerDto dto,Manager entity) {
		entity.setName(dto.getName());
		entity.setEmail(dto.getEmail());
		entity.setAddress(dto.getAddress());
		entity.setContrycode(dto.getContrycode());
		entity.setDivision(dto.getDivision());
		entity.setPhone(dto.getPhone());
		entity.setPin(dto.getPin());
		entity.setSalary(dto.getSalary());
	
		
	}
	public void mapEntityToDTO(ManagerDto dto,Manager entity) {
		dto.setName(entity.getName());
		dto.setEmail(entity.getEmail());
		dto.setAddress(entity.getAddress());
		dto.setContrycode(entity.getContrycode());
		dto.setDivision(entity.getDivision());
		dto.setPhone(entity.getPhone());
		dto.setPin(entity.getPin());
		dto.setSalary(entity.getSalary());
		
	}
	public List<ManagerDto> findAllManager() {
		List<Manager> list=managerRepo.findAll();
		List<ManagerDto> dtoList=new ArrayList<>();
		for(Manager m:list) {
			ManagerDto dto=new ManagerDto();
			mapEntityToDTO(dto, m);
			dtoList.add(dto);
		}
		return dtoList;
	}

}
