package com.rbu.ecom.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rbu.ecom.dto.ManagerDto;
import com.rbu.ecom.jpa.model.Manager;
import com.rbu.ecom.service.ManagerService;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;

@RestController
@RequestMapping(path = "/admin/api/v1/manager", produces = MediaType.APPLICATION_JSON_VALUE)
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ManagerRestController {
	@Autowired
	ManagerService managerService;

	@PostMapping
	@ApiResponse(responseCode = "201")
	public ResponseEntity<Long> createManager(@RequestBody @Valid final ManagerDto dto) {
		Long id = managerService.createManager(dto);
		ResponseEntity<Long> response = new ResponseEntity<Long>(id, HttpStatus.CREATED);
		return response;
	}

	@GetMapping
	@ApiResponse(responseCode = "200")
	public ResponseEntity<List<ManagerDto>> getAllManagers() {
		List<ManagerDto> list = managerService.findAllManager();
		ResponseEntity<List<ManagerDto>> response = new ResponseEntity<List<ManagerDto>>(list, HttpStatus.OK);
		return response;
	}

}
